# Case-Management
La soluzione di Case Management rappresenta un’applicazione complessa che richiede una combinazione di attività umane e flussi di lavoro al fine di supportare processi complessi come ad esempio quello previsto per il caso infermieristico.

PER MAGGIORI INFO: [Readme Case Management.pdf](https://github.com/Jamio-openwork/Case-Management/files/7761310/Readme.Case.Management.pdf)
![IMGCase](https://user-images.githubusercontent.com/86653778/147066363-82ac90d1-cd65-47f8-8109-7d31c8b5ee03.png) 
